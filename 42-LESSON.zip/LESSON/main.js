//  FOR 39
// let a = 3;
// let b = 7;
// for (let i = a; i <= b; i++) {
//   for (let j = 1; j <= i; j++) {
//     console.log(i);
//   }
// }

//  FOR 37
// let N = 3;
// let sum = 0;
// for (let i = 1; i <= N; i++) {
//   let multiply = 1;
//   for (let j = 1; j <= i; j++) {
//     multiply *= i;
//   }
//   sum += multiply;
// }
// console.log(sum);

// //////// F U N C T I O N S   ////////////////

//  FUNCTION DECLARATION //////////////
// function say(message) {
//   console.log(message);
// }

// say('Hello');
// say('Hello');
// say('Hello');
// say('Hello');
// say('Hello');
// say('Hello');
// say('Hello');
// say('Hello');

// function add(a, b) {
//   console.log(a + b);
// }

// add(3, 5);

//  PARAMETERS & ARGUMENTS
// function fullName(first_name, second_name) {
//   console.log('Hello ' + first_name + ' ', second_name);
// }

// // first_name, second_name - parameters

// fullName('Sultonqul', 'Programmer');

// // "Sultonqul", "Programmer" - arguments

// LOCAL SCOPE
// function showMessage() {
//   var message = "Hello, I'm JavaScript!"; // local variable

//   alert(message);
// }
// showMessage(); // Hello, I'm JavaScript!

// alert(message); // <-- Error! The variable is local to the function

// function say(message) {
//   console.log(message);
// }

// let result = say('Hello');
// console.log('Result:', result);

// output

// Hello
// Result: undefined

// function add(a, b) {
//   return a + b;
// }

// let result = add(4, 7); // 11
// console.log(result);
// console.log(add(4, 7));

// function compare(a, b) {
//   if (a > b) {
//     return -1;
//   } else if (a < b) {
//     return 1;
//   } else {
//     return 0;
//   }
// }

// compare(4, 9); // 1
// console.log(compare());

// function display(a) {
//   return a;
// }
// console.log(display());

// function say(message) {
//   // show nothing if the message is empty
//     if (!message) {
//       return;
//     }
//   console.log(message);
// }

// say();

// DEFAULT VALUES

// function showMessage(from, text = 'no text given') {
//   alert(from + ': ' + text);
// }

// /* function showMessage(from) {
//     if (typeof text == undefined) {text = "no text given"}
//     alert( from + ": " + text );
//   } */

// showMessage('Ann', 'Salom'); // Ann: no text given

// showMessage('Ann', undefined); // Ann: no text given

//  FUNCTIONS ARE FIRST CLASS CITIZENS
// function add(a, b) {
//   return a + b;
// }
// console.log(add);
// let sum = add();
// console.log(sum);
// console.log(add(3, 4));

// function average(a, b, fn) {
//   return fn(a, b) / 2;
// }

// function sum(a, b) {
//   return a + b;
// }

// let result = average(10, 20, sum);

// console.log(result);

// ///// ANONYMOUS FUNCTION   ///////////////
// IIFE
// (function (parameters) {
//     //...
//  })(arguments);

// (function (a, b) {
//   console.log(a + b);
// })(3, 4);

//  FUNCTION EXPRESSION
// let show = function () {
//   console.log('Function expression');
// };
// show();

//  ARROW FUNCTION
// let show =  () => {
//   console.log('Function expression');
// };
// show();

// let add = (a, b) => {
//   return a + b;
// };

// console.log(add(4, 8));

let add = (a, b) => a + b;

console.log(add(4, 8));
